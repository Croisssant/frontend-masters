# Ch 3d: Easy design-tablet-begin

A Pen created on CodePen.io. Original URL: [https://codepen.io/Lim-Kai-Wey/pen/xxmmPKP](https://codepen.io/Lim-Kai-Wey/pen/xxmmPKP).

